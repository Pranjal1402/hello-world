create table  MOBILE_EMAIL_CHANGE_TXN
(
CUSTOMER_ID VARCHAR(50),
TXN_ID VARCHAR(50),
TXN_TIMESTAMP VARCHAR2(20),
CHG_TYPE VARCHAR(20),
ACCOUNT_TYPE VARCHAR(20),
ACCOUNT_NUMBER VARCHAR(30),
IFSC VARCHAR(11),
NAME VARCHAR2(150),
MOBILE_NUMBER VARCHAR2(10),
EMAIL_ID VARCHAR2(100),
BATCH_TIMESTAMP VARCHAR2(20)
);


create table  STG_MOBILE_EMAIL_CHANGE_TXN
(
CUSTOMER_ID VARCHAR(50),
TXN_ID VARCHAR(50),
TXN_TIMESTAMP VARCHAR2(20),
CHG_TYPE VARCHAR(20),
ACCOUNT_TYPE VARCHAR(20),
ACCOUNT_NUMBER VARCHAR(30),
IFSC VARCHAR(11),
NAME VARCHAR2(150),
MOBILE_NUMBER VARCHAR2(10),
EMAIL_ID VARCHAR2(100),
BATCH_TIMESTAMP VARCHAR2(20)
);


CREATE KEYSPACE ifrm_uds
WITH replication = {'class':'SimpleStrategy', 'replication_factor' : 3};

CREATE TABLE IF NOT EXISTS contact_change_info_txns (
    txn_id text,
    txn_timestamp timestamp,
    customer_id text,
    account_number text,
    name text,
    mobile text,
    email text,
    change_type text,
    account_type text,
    ifsc text,
    PRIMARY KEY (customer_id, txn_timestamp, txn_id)
) WITH CLUSTERING ORDER BY (txn_timestamp DESC);
