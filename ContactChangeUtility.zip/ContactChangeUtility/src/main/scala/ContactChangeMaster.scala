import com.datastax.oss.driver.api.core.cql.{BoundStatement, PreparedStatement}

import akka.actor.ActorSystem
import akka.stream.ActorMaterializer
import akka.stream.alpakka.cassandra.{CassandraSessionSettings, CassandraWriteSettings}
import akka.stream.alpakka.cassandra.javadsl.{CassandraFlow, CassandraSessionRegistry}
import akka.stream.alpakka.slick.scaladsl.{Slick, SlickSession}
import akka.stream.scaladsl.{Sink, Source}
import org.slf4j.LoggerFactory
import slick.basic.DatabaseConfig
import slick.jdbc.{GetResult, JdbcProfile}

import scala.concurrent.duration.DurationInt
case class ContactChange(customerId:String,txnId:String,txnTimestamp:String,
                changeType:String,accountType:String,accountNumber:String,
                ifsc:String,name:String,mobileNumber:String,
                emailId:String,batchTimestamp:String)

 object ContactChangeMaster extends App {

  implicit val system = ActorSystem("EchoServer")
  implicit val ec = system.dispatcher
  implicit val materializer = ActorMaterializer()
   val logger = LoggerFactory.getLogger(getClass)

   val sessionSettings = CassandraSessionSettings("example-with-akka-discovery")
   implicit val session = CassandraSessionRegistry.get(system).sessionFor(sessionSettings)


   val databaseConfig = DatabaseConfig.forConfig[JdbcProfile]("slick-oracle")
  implicit val sessions = SlickSession.forConfig(databaseConfig)
  system.registerOnTermination(sessions.close())

  implicit val getTxnsByCustResult = GetResult(r => {
    ContactChange(r.nextString, r.nextString,r.nextString, r.nextString,
      r.nextString, r.nextString,r.nextString, r.nextString,
      r.nextString, r.nextString,r.nextString)
  })

  import sessions.profile.api._

  val src1 = Source.tick(1.seconds, 25.seconds, 10)

  val custTxnsInfo = Slick
    .source(sql"""
    SELECT
    customer_id,txn_id,txn_timestamp,
     chg_type,account_type,account_number,IFSC,name,
     mobile_number,email_id,batch_timestamp from STG_MOBILE_EMAIL_CHANGE_TXN
      where trunc(TO_DATE(batch_timestamp, 'YYYY-MM-DD HH24:MI:SS')) = trunc(sysdate-1)
  """.as[ContactChange])

   custTxnsInfo
     .runWith(Slick.sink(contactChange =>
       sqlu"""insert into mobile_email_change_txn (customer_id,txn_id,txn_timestamp,chg_type,account_type,
account_number,ifsc,name,mobile_number,email_id,batch_timestamp)
     values
     (
         ${contactChange.customerId},${contactChange.txnId},${contactChange.txnTimestamp},
         ${contactChange.changeType},${contactChange.accountType},${contactChange.accountNumber},
         ${contactChange.ifsc},${contactChange.name},${contactChange.mobileNumber},
         ${contactChange.emailId},${contactChange.batchTimestamp}
     )""")
     )

   val statementBinder = (contactChange:ContactChange, preparedStatement:PreparedStatement,boundStatement:BoundStatement) => preparedStatement.bind(contactChange.customerId)

   val cass = custTxnsInfo.via(CassandraFlow.create(CassandraWriteSettings.defaults,
     s"""Insert into ifrm_universal_data_store.customer(
        |customer_id
        | values(?)""".stripMargin,
     statementBinder)).runWith(Sink.foreach(
     x => {
       logger.info(x.toString)
     }))
}
